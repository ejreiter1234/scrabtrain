# Scrabble 2s & 3s Trainer

A mobile-friendly web app for practicing 2 and 3 letter Scrabble words — TWL and SOWPODS dictionaries, with a scored practice mode, full word list browser, instant word lookup, and an anagram tool.

It's a single self-contained file (`index.html`) — no build step, no server, no dependencies.

## Deploy with GitHub Pages (free)

1. Create a new GitHub repository (public works fine — e.g. `scrabble-trainer`).
2. Upload `index.html` to the root of the repo (drag-and-drop on github.com works, or use git — see below).
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source** to **Deploy from a branch**, branch **main**, folder **/(root)**.
5. Save. GitHub will give you a URL like:
   `https://YOUR-USERNAME.github.io/scrabble-trainer/`
   (takes a minute or two to go live the first time.)

### Using git from the command line instead of the web UI

```bash
git init
git add index.html README.md
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/scrabble-trainer.git
git push -u origin main
```

Then enable Pages as in step 3 above.

## Add it to your phone's home screen

Once the GitHub Pages URL is live:

- **iPhone (Safari):** open the link → tap the Share icon → **Add to Home Screen**.
- **Android (Chrome):** open the link → tap the ⋮ menu → **Add to Home Screen** (or "Install app").

This gives you a real home-screen icon that opens full-screen, without browser address bars — basically an app, no App Store needed.

## Notes

- Progress (rounds played, accuracy, missed-word bank) is saved in the browser's local storage on whichever device/browser you use it from. It isn't synced across devices.
- Word lists for 2 and 3 letter words are compiled from public Scrabble references for study purposes. Lookups for 4+ letter words fall back to a live general-English-dictionary check (not official Scrabble validation).
- No backend, no accounts, no tracking, no ads (yet) — just a static file.

## Future: native app (iOS / Android)

This vanilla HTML/CSS/JS should port cleanly into a [Capacitor](https://capacitorjs.com/) or Cordova wrapper for App Store / Play Store distribution with ads, since there's no framework lock-in. That's a good next step once the web version has been tested.
